"""credenz URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url,include
from clash import views
from django.conf.urls import url
from django.contrib import admin
from clash.models import Player

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', views.register),
    url(r'^next/', views.my_view),
    url(r'^login/', views.index),
    url(r'^reg/', views.reg),
    url(r'^logout/', views.logout_view),
    url(r'^leaderboard/', views.display),
    url(r'^questions/', views.que),
    url(r'^time/', views.displayTime),
    #url(r'^que1/', views.que1),
    #url(r'^que2/', views.que2),
    url(r'^que(?P<id>[0-6]+)/', views.que1,name='question'),
]


