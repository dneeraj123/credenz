from django.shortcuts import render
from django.contrib.auth import logout
# Create your views here.
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from .models import Player
from .models import Questions
#from datetime import datetime
import datetime
h=int(datetime.datetime.now().strftime("%H"))
m=int(datetime.datetime.now().strftime("%M"))
s=int(datetime.datetime.now().strftime("%S"))

t=(h*3600)+(m*60)+s
endtime=3000
"""def my_view(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        #request.session.set_expiry(60)
        return render(request,'instruction.html')
    else:
        #print("Invalid")
        return render(request, 'test.html')
"""


def login(request):
    h = int(datetime.datetime.now().strftime("%H"))
    m = int(datetime.datetime.now().strftime("%M"))
    s = int(datetime.datetime.now().strftime("%S"))

    t = (h * 3600) + (m * 60) + s

    if endtime <= t:
        return render(request, 'test.html')
    else:
        return render(request, 'login.html')



def register(request):
    h = int(datetime.datetime.now().strftime("%H"))
    m = int(datetime.datetime.now().strftime("%M"))
    s = int(datetime.datetime.now().strftime("%S"))

    t = (h * 3600) + (m * 60) + s

    if endtime <= t:
        return render(request, 'test.html')
    else:
        return render(request, 'register.html')



def reg(request):
    username = request.POST['username']
    password = request.POST['password']
    user = User.objects.create_user(username,'abc@gmail.com', password)
    player = Player.objects.create(p1_name = request.POST['player1_name'],p2_name = request.POST['player2_name'],p1_email = request.POST['player1_email'], p2_email = request.POST['player2_email'],user=user, p1_phone = request.POST['player1_phone'], p2_phone = request.POST['player2_phone'])
    #user.save()
    player.save()
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
       # request.session.set_expiry(60)
    else:
        return render(request, 'test.html')

    if request.user.is_authenticated():
        if endtime > t:
            p = Questions.objects.all()
            context = {
                'que': p
            }
            return render(request, 'questions.html', context)
        else:
            logout_view()
            return render(request, 'test.html')
    else:
        return render(request, 'test.html')

            #return render(request,'thank.html')


def logout_view(request):
    logout(request)
    return render(request, 'logout.html')


def leaderboard(request):
    p=Player.objects.all().order_by('user')

    context={
        'pl':p,
    }
    return render(request, 'leaderboard.html',context)

def que(request):
    #p=Questions.objects.filter(id=1)
    h = int(datetime.datetime.now().strftime("%H"))
    m = int(datetime.datetime.now().strftime("%M"))
    s = int(datetime.datetime.now().strftime("%S"))

    t = (h * 3600) + (m * 60) + s
    if endtime>t:
        if request.user.is_authenticated():
            p = Questions.objects.all()
            context={
                'que':p
            }
            return render(request,'questions.html',context)
        else:
            return render(request, 'test.html')
    else:
        return render(request, 'test.html')


def queSort(request,id):
    p = Questions.objects.filter(id=id)
    context={
        'que1':p
    }
    h = int(datetime.datetime.now().strftime("%H"))
    m = int(datetime.datetime.now().strftime("%M"))
    s = int(datetime.datetime.now().strftime("%S"))

    t = (h * 3600) + (m * 60) + s
    print(t)
    if endtime > t:
        return render(request,'question2.html',context)
    else:
        return render(request,'test.html')

def quelinks(request):
    return render(request,'questions.html')


def displayTime(request):
    #print(datetime.now())
    return render(request,"time.html")


def compiler(request):
    h = int(datetime.datetime.now().strftime("%H"))
    m = int(datetime.datetime.now().strftime("%M"))
    s = int(datetime.datetime.now().strftime("%S"))

    t = (h * 3600) + (m * 60) + s

    if endtime > t:
        s=request.POST["content"]
        s1 = request.POST["content1"]
        print(s)
        print(s1)
        print("g++ "+s1)
        print("./a.out")
        return render(request,"submission.html")
    else:
        return render(request, "test.html")

