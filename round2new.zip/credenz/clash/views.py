from django.shortcuts import render
from django.contrib.auth import logout
# Create your views here.
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from .models import Player
from .models import Questions
from datetime import datetime

start = 20*3600

def my_view(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        request.session.set_expiry(60)
        return render(request,'instruction.html')
    else:
        #print("Invalid")
        return render(request, 'test.html')


def index(request):
    return render(request, 'login.html')


def register(request):
    return render(request, 'register.html')


def reg(request):
    username = request.POST['username']
    password = request.POST['password']
    user = User.objects.create_user(username,'abc@gmail.com', password)
    player = Player.objects.create(p1_name = request.POST['player1_name'],p2_name = request.POST['player2_name'],p1_email = request.POST['player1_email'], p2_email = request.POST['player2_email'],user=user, p1_phone = request.POST['player1_phone'], p2_phone = request.POST['player2_phone'])
    #user.save()
    player.save()
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        request.session.set_expiry(60)
    else:
        # print("Invalid")
        return render(request, 'test.html')

    if request.user.is_authenticated():
        p = Questions.objects.all()
        context = {
            'que': p
        }
        return render(request, 'questions.html', context)
    else:
        return render(request, 'test.html')

            #return render(request,'thank.html')


def logout_view(request):
    logout(request)
    return render(request, 'logout.html')


def display(request):
    p=Player.objects.all().order_by('user')

    context={
        'pl':p,
    }
    return render(request, 'leaderboard.html',context)

def que(request):
    #p=Questions.objects.filter(id=1)
    if request.user.is_authenticated():
        p = Questions.objects.all()
        context={
            'que':p
        }
        return render(request,'questions.html',context)
    else:
        return render(request, 'test.html')


def que1(request,id):
    p=Questions.objects.filter(id=id)
    context={
        'que1':p
    }
    return render(request,'question2.html',context)


def quelinks(request):
    return render(request,'questions.html')

def displayTime(request):
    #print(datetime.now())
    return render(request,"time.html")

