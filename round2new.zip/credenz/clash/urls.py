from . import views
from django.conf.urls import url
from django.contrib import admin


urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$',views.index ),
    url(r'^next/',views.my_view),
    url(r'^register/',views.register),
    url(r'^reg/',views.reg),
    url(r'^logout/',views.logout_view),
    url(r'^leaderboard/',views.display),
]
