from django.db import models
from django.contrib.auth.models import User


class Player(models.Model):
    p1_name=models.CharField(max_length=120)
    p2_name=models.CharField(max_length=120)
    p1_email=models.EmailField(max_length=100)
    p2_email=models.EmailField(max_length=100)
    user=models.OneToOneField(User,default=0,unique=True)
    p1_phone=models.BigIntegerField(default=0)
    p2_phone=models.BigIntegerField(default=0)
    total_score=models.IntegerField(default=0)
    total_time=models.IntegerField(default=0)


class Questions(models.Model):
    title=models.CharField(max_length=500)
    question_text=models.TextField()


class Que_attempts(models.Model):
    score=models.IntegerField()
    time=models.IntegerField(default=0)
    user=models.ForeignKey(User)
    que=models.ForeignKey(Questions)
