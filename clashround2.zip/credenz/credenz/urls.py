"""credenz URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url,include
from clash import views
from django.conf.urls import url
from django.contrib import admin
from clash.models import Player

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', views.register),
    url(r'^login/', views.time_check),
    url(r'^questions/', views.queList),
    url(r'^logout/', views.logout_view),
    url(r'^leaderboard/', views.leaderboard),
    url(r'^submit/', views.compiler,name='timeend'),
    url(r'^about/', views.aboutus),
    url(r'^MySubmissions/', views.mysubmission),
    url(r'^que(?P<id>[0-6]+)/', views.queSort,name='question'),
    url(r'^que/(?P<id>[0-9]+)/(?P<subid>[0-9]+)/$', views.submissionSort,name='submission'),
    url(r'^loadbuffer/$', views.load_buffer),
    url(r'^validate_username/', views.check_username),

    url(r'^savefile/$', views.save_code_file),
]


