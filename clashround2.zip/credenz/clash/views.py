from django.shortcuts import render
from django.contrib.auth import logout
from django.contrib.auth import authenticate
from django.contrib.auth import login
from django.contrib.auth.models import User
from .models import Player
from .models import Questions
from .models import Que_attempts
import os,json
from django.http import HttpResponse,JsonResponse,HttpRequest
import datetime
import random


start=0*3600+(0*60)
endtime=(24*3600)+(17*60)
globid=0
extension=['1','2','3','4','5','6']
test=[0,20]
testcase=[random.choice(test),random.choice(test),random.choice(test),random.choice(test),random.choice(test)]
addpenalty=2
def aboutus(request):
    return render(request, 'about.html')
def time_validate(request):
    h = int(datetime.datetime.now().strftime("%H"))
    m = int(datetime.datetime.now().strftime("%M"))
    s = int(datetime.datetime.now().strftime("%S"))
    t = (h * 3600) + (m * 60) + s
    return t

def time_check(request):
    t=time_validate(request)
    if t<start:
        return render(request, 'about.html')
    else:
        if endtime <= t:
            return render(request, 'test.html')
        else:
            return render(request, 'login.html')
def register(request):
    t=time_validate(request)
    if t<start:

        return render(request, 'about.html')

    else:
        if endtime <= t:
            return render(request, 'test.html')
        else:
            return render(request, 'register.html')


def check_username(request):
    username = request.GET.get('username', None)
    data = {
        'is_taken': User.objects.filter(username__iexact=username).exists()
    }
    return JsonResponse(data)



def queList(request):
    #t=time_validate(request)
    h = int(datetime.datetime.now().strftime("%H"))
    m = int(datetime.datetime.now().strftime("%M"))
    s = int(datetime.datetime.now().strftime("%S"))
    t = (h * 3600) + (m * 60) + s
    if t < start:
        return render(request, 'about.html')
    else:
        if endtime <= t:
            return render(request, 'test.html')
        else:
            if request.user.is_authenticated():
                p = Questions.objects.all()
                context = {
                    'que': p,
                    'time': endtime,
                }

                user_folder_create(request)

                return render(request, 'questions.html', context)
            else:
                username = request.POST['username']
                password = request.POST['password']
                user = User.objects.create_user(username,"abc@gmail.com",password)
                player = Player.objects.create(p1_name = request.POST['player1_name'],p2_name = request.POST['player2_name'],p1_email = request.POST['player1_email'], p2_email = request.POST['player2_email'],user=user, p1_phone = request.POST['player1_phone'], p2_phone = request.POST['player2_phone'])
                player.save()
                user = authenticate(request, username=username, password=password)
                if user is not None:
                    login(request,user)
                else:
                    return render(request, 'test.html')

                if request.user.is_authenticated():
                    p = Questions.objects.all()
                    context = {
                        'que': p,
                        'time': endtime,
                    }
                    user_folder_create(request)
                    return render(request, 'questions.html', context)
                else:
                    return render(request, 'test.html')

def logout_view(request):
    logout(request)
    return render(request, 'logout.html')

def leaderboard(request):
    t=time_validate(request)
    if t < start:
        return render(request, 'about.html')
    else:
        count=Player.objects.all().count()
        p=Player.objects.all().order_by('-total_score','total_time','user')

        context={
        'pl':p,
        'count':count
        }
    return render(request, 'leaderboard.html',context)

"""
def que(request):
    t=time_validate(request)
    if endtime>t and start<=t:
        if request.user.is_authenticated:
            p = Questions.objects.all()
            context = {
                'que': p,
                'endtime': endtime,
            }
            return render(request, 'questions.html', context)
        else:
            user = authenticate(request, username=request.POST["username"], password=request.POST["password"])
            if user is not None:
                h = int(datetime.datetime.now().strftime("%H"))
                m = int(datetime.datetime.now().strftime("%M"))
                s = int(datetime.datetime.now().strftime("%S"))

                login(request,user)
                p = Questions.objects.all()
                context={
                    'que':p,
                    'endtime': endtime,
                }
                return render(request,'questions.html',context)
            else:
                return render(request, 'test.html')
    else:
        return render(request, 'about.html')

"""
def submissionSort(request,id,subid):

    t = time_validate(request)
    p = Questions.objects.filter(id=id)
    currentid = str(request.user.id - 1)
    path = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + currentid + "/" + str(id)
    ext=request.POST["id"+str(id)+str(subid)]
    f = open(path + "/codefile" + str(subid) + ext).read()
    context = {
        'que1': p,
        'time': endtime,
        'userid': request.user.id - 1,
        'questionid': globid,
        'ext': extension[int(globid) - 1],
        'readcontent': f
    }
    if start > t:
        return render(request, 'about.html', context)
    else:
        if endtime > t:
            return render(request, 'question2.html', context)
        else:
            return render(request, 'test.html')

def queSort(request,id):
        global globid
        globid=str(id)
        t = time_validate(request)
        p = Questions.objects.filter(id=id)
        context={
            'que1':p,
            'time': endtime,
            'userid': request.user.id-1,
            'questionid': globid,
            'ext':extension[int(globid)-1],
            'readcontent':"//Code goes here"

        }
        if start>t:
            return render(request, 'about.html', context)
        else:
            if endtime > t:
                return render(request,'question2.html',context)
            else:
                return render(request,'test.html')

def dispatch(request):
    if request.POST['save']==1:
        return save_code_file(request)
    else:
        return compiler(request)

def save_file_create(request,code):
    current_user_id = (request.user.id) - 1
    current_user_id = str(current_user_id)
    ext = request.POST["lang"]
    global extension
    extension[int(globid) - 1] = ext
    #filename = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id),que=Questions.objects.all().filter(id=globid)).count()+1
    DIR = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + current_user_id + "/" + str(globid)
    x = len([name for name in os.listdir(DIR) if os.path.isfile(os.path.join(DIR, name))])

    path = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + current_user_id + "/" + str(globid)
    f = open(path + "/codefile" + str(x+1) + ext, 'w+')
    f.write(code)
    f.close()


def save_code_file(request):
    if request.is_ajax():

                question_folder_create(request)
                code = request.POST["content"]

                user = User.objects.get(id=request.user.id)
                ext = request.POST["lang"]


                save_file_create(request, code)
                s="Saved"
                print(s)
                return HttpResponse(json.dumps({'key':s}),content_type='application/json')



def load_buffer(request):


    if request.is_ajax():
        currentid=str(request.user.id-1)

        y = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id),que=Questions.objects.filter(id=globid))
        DIR = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + currentid + "/" + str(globid)
        x = len([name for name in os.listdir(DIR) if os.path.isfile(os.path.join(DIR, name))])
        print(x)
        path1 = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + currentid + "/" + str(globid)+ "/codefile" + str(x) +".c"
        path2 = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + currentid + "/" + str(globid) + "/codefile" + str(x) + ".cpp"

        if not os.path.exists(path1):
            f = open(path2).read()
        else:
            f = open(path1).read()

        return HttpResponse(json.dumps({'key': f}), content_type='application/json')

    else:
        print("error")


def compiler(request):
    t=time_validate(request)
    if t>start:
        if t<=endtime:
            question_folder_create(request)
            code = request.POST["content"]
            s1 = request.POST["content1"]
            testcase = [random.choice(test), random.choice(test), random.choice(test), random.choice(test), random.choice(test)]
            t = [0, 0, 0, 0, 0, 0]
            p = Player.objects.all().filter(id=request.user.id-1)
            score=0
            for i in range(5):
                score+=testcase[i]

            n = (100 - score) / 20
            penaltytime = n * addpenalty
            testcaseScore=score
            curr_time = time_validate(request)
            user=User.objects.get(id=request.user.id)
            ext = request.POST["lang"]
            BestScoreTime=[0,0,0,0,0,0]
            for i in range(6):
                question = Questions.objects.get(id=str(i+1))
                q = Que_attempts.objects.filter(user=user,que=question)
                for x in q:
                    if x.score>t[i]:
                        t[i]=x.score
                        BestScoreTime[i] = x.time

            question = Questions.objects.get(id=globid)
            questionattempt = Que_attempts.objects.create(score=testcaseScore, time=(curr_time)-start, user=user,que=question, penalty=penaltytime,extension=ext)
            z = Player.objects.get(id=request.user.id - 1)
            if testcaseScore > t[int(globid)-1]:
                z.total_time=z.total_time-BestScoreTime[int(globid)-1]+time_validate(request)-start
            x=z.total_time+(penaltytime*60)
            z.total_time=x
            q = Player.objects.filter(id=request.user.id - 1).update(total_time=z.total_time)
            questionattempt.save()
            code_file_create(request, code)
            t1 = [0, 0, 0, 0, 0, 0]
            for i in range(6):
                question = Questions.objects.get(id=str(i+1))
                q = Que_attempts.objects.filter(user=user,que=question)
                for x in q:
                    if x.score>t1[i]:
                        t1[i]=x.score

            q = Player.objects.filter(id=request.user.id - 1).update(total_score=t1[0]+t1[1]+t1[2]+t1[3]+t1[4]+t1[5])
            context1 = {
                'time': time_validate(request),
                'pl': p,
                'list':testcase,
                'score':testcaseScore
            }
            return render(request,"submission.html",context1)

        else:
            return render(request, "test.html")
    else:
        return render(request, "about.html")


def question_folder_create(request):
    global globid

    current_user_id=(request.user.id)-1
    current_user_id=str(current_user_id)
    path = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + current_user_id + "/" + str(globid)
    if not os.path.exists(path):
        os.mkdir(path)
    else:
        print("File exists")

def user_folder_create(request):
    path1 = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/'

    if not os.path.exists(path1):
        os.mkdir(path1)
    else:
        print("File exists")

    current_user_id=(request.user.id)-1
    current_user_id=str(current_user_id)
    path = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + current_user_id
    if not os.path.exists(path):
        os.mkdir(path)
    else:
        print("File exists")


def mysubmission(request):
    p1 = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id),que=Questions.objects.filter(id=1))
    p2 = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id), que=Questions.objects.filter(id=2))
    p3 = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id), que=Questions.objects.filter(id=3))
    p4 = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id), que=Questions.objects.filter(id=4))
    p5 = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id), que=Questions.objects.filter(id=5))
    p6 = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id), que=Questions.objects.filter(id=6))

    attemptlist=[p1,p2,p3,p4,p5,p6]
    cnt = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id)).count()

    countindividualque=[p1.count(),p2.count(),p3.count(),p4.count(),p5.count(),p6.count()]
    context={
        'attempt1':p1,
        'attempt2':p2,
        'attempt3': p3,
        'attempt4': p4,
        'attempt5': p5,
        'attempt6': p6,
        'cnt':cnt,
        'ciq1':p1.count(),
        'ciq2': p2.count(),
        'ciq3': p3.count(),
        'ciq4': p4.count(),
        'ciq5': p5.count(),
        'ciq6': p6.count()
    }

    return render(request,"Mysubmissions.html",context)

def code_file_create(request,code):
    current_user_id = (request.user.id)-1
    current_user_id = str(current_user_id)
    ext=request.POST["lang"]
    global extension
    extension[int(globid)-1]=ext
   # filename=Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id),que=Questions.objects.all().filter(id=globid)).count()

    path = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + current_user_id + "/" + str(globid)
    x = len([name for name in os.listdir(path) if os.path.isfile(os.path.join(path, name))])
    x=x+1
    f=open(path+"/codefile"+str(x)+ext,'w+')
    f.write(code)
    f.close()
