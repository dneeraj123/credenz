from django.contrib import admin
from .models import Player
from .models import Questions
from .models import Que_attempts
# Register your models here.
admin.site.register(Player)
admin.site.register(Questions)
admin.site.register(Que_attempts)