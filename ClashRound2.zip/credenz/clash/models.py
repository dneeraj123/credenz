from django.db import models
from django.contrib.auth.models import User


class Player(models.Model):
    p1_name=models.CharField(max_length=120)
    p2_name=models.CharField(max_length=120)
    p1_email=models.EmailField(max_length=100)
    p2_email=models.EmailField(max_length=100)
    user=models.OneToOneField(User,default=0,unique=True)
    p1_phone=models.CharField(max_length=10)
    p2_phone=models.CharField(max_length=10)
    total_score=models.IntegerField(default=0)
    total_time=models.IntegerField(default=0)



class Questions(models.Model):
    title=models.CharField(max_length=500)
    question_text=models.TextField()
    flag=models.IntegerField(default=0)

class Que_attempts(models.Model):
    score=models.IntegerField()
    time=models.IntegerField(default=0)
    user=models.ForeignKey(User,default=0)
    #uid=models.IntegerField(default=0)
    que=models.ForeignKey(Questions,default=0)
    penalty=models.IntegerField(default=0)
    extension=models.CharField(max_length=4,default=".c")
    submissionNo=models.IntegerField(default=1)
    #qid = models.IntegerField(default=0)

class test(models.Model):
    user_que_attempt_number = models.IntegerField(default=0)
    #user = models.ForeignKey(User, default=0)
    #que = models.ForeignKey(Questions, default=0)
    que_attempt = models.ForeignKey(Que_attempts, default=0)



