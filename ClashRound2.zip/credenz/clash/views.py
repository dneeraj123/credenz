from django.shortcuts import render
from django.contrib.auth import logout
# Create your views here.
from django.contrib.auth import authenticate
from django.contrib.auth import login
from django.contrib.auth.models import User
from .models import Player
from .models import Questions
from .models import Que_attempts
from random import randint
from django.http import HttpResponse
import os,errno,sys
from django.conf import settings
#from datetime import datetime
import datetime
import random
from django import template
register = template.Library()




start=19*3600+(60*30)
endtime=(24*3600)+(17*60)
globid=0
prev_time=0
st=[0,0,0,0,0,0]
extension=['1','2','3','4','5','6']

test=[0,20]

testcase=[random.choice(test),random.choice(test),random.choice(test),random.choice(test),random.choice(test)]

addpenalty=2

"""def my_view(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        #request.session.set_expiry(60)
        return render(request,'instruction.html')
    else:
        #print("Invalid")
        return render(request, 'test.html')
"""
def aboutus(request):
    return render(request, 'about.html')


def time_validate(request):
    h = int(datetime.datetime.now().strftime("%H"))
    m = int(datetime.datetime.now().strftime("%M"))
    s = int(datetime.datetime.now().strftime("%S"))
    t = (h * 3600) + (m * 60) + s

    return t


def time_check(request):
    t=time_validate(request)
    if t<start:
        return render(request, 'about.html')

    else:
        if endtime <= t:
            return render(request, 'test.html')
        else:
            return render(request, 'login.html')


def register(request):
    t=time_validate(request)
    if t<start:
        return render(request, 'about.html')

    else:
        if endtime <= t:
            return render(request, 'test.html')
        else:
            return render(request, 'register.html')



def queList(request):
    #t=time_validate(request)
    h = int(datetime.datetime.now().strftime("%H"))
    m = int(datetime.datetime.now().strftime("%M"))
    s = int(datetime.datetime.now().strftime("%S"))
    t = (h * 3600) + (m * 60) + s
    print(t)
    print(start)
    print(endtime)
    if t < start:
        return render(request, 'about.html')

    else:
        if endtime <= t:
            return render(request, 'test.html')


        else:
            if request.user.is_authenticated():
                p = Questions.objects.all()
                context = {
                    'que': p,
                    'time': endtime,
                }

                user_folder_create(request)
                return render(request, 'questions.html', context)
            else:
                username = request.POST['username']
                password = request.POST['password']
                user = User.objects.create_user(username,"abc@gmail.com",password)
                user.save()
                player = Player.objects.create(p1_name = request.POST['player1_name'],p2_name = request.POST['player2_name'],p1_email = request.POST['player1_email'], p2_email = request.POST['player2_email'],user=user, p1_phone = request.POST['player1_phone'], p2_phone = request.POST['player2_phone'])
    #user.save()

                player.save()
                user = authenticate(request, username=username, password=password)

                if user is not None:
                    h = int(datetime.datetime.now().strftime("%H"))
                    m = int(datetime.datetime.now().strftime("%M"))
                    s = int(datetime.datetime.now().strftime("%S"))


                    login(request,user)


                else:
                    return render(request, 'test.html')

                if request.user.is_authenticated():
                    p = Questions.objects.all()
                    context = {
                        'que': p,
                        'time': endtime,


                    }

                    user_folder_create(request)
                    return render(request, 'questions.html', context)
                else:
                    return render(request, 'test.html')

            #return render(request,'thank.html')


def logout_view(request):
    logout(request)
    return render(request, 'logout.html')



def leaderboard(request):
    t=time_validate(request)
    if t < start:
        return render(request, 'about.html')

    else:
        count=Player.objects.all().count()
        p=Player.objects.all().order_by('-total_score','total_time','user')

        context={
        'pl':p,
        'count':count
        }

    return render(request, 'leaderboard.html',context)


def que(request):
    #p=Questions.objects.filter(id=1)
    t=time_validate(request)


    if endtime>t and start<=t:
        if request.user.is_authenticated:
            p = Questions.objects.all()
            context = {
                'que': p,
                'endtime': endtime,
            }
            return render(request, 'questions.html', context)
        else:
            user = authenticate(request, username=request.POST["username"], password=request.POST["password"])
            if user is not None:
                h = int(datetime.datetime.now().strftime("%H"))
                m = int(datetime.datetime.now().strftime("%M"))
                s = int(datetime.datetime.now().strftime("%S"))

                login(request,user)
                p = Questions.objects.all()
                context={
                    'que':p,
                    'endtime': endtime,
                }
                return render(request,'questions.html',context)
            else:
                return render(request, 'test.html')
    else:
        return render(request, 'about.html')


def submissionSort(request,id,subid):

    t = time_validate(request)
    p = Questions.objects.filter(id=id)
    currentid = str(request.user.id - 1)
    path = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + currentid + "/" + str(id)
    print(id)
     #queExt = Que_attempts.objects.all().filter(user=User.objects.filter(id=request.user.id),que=Questions.objects.all().filter(id=globid))

    ext=request.POST["id"+str(id)+str(subid)]


    f = open(path + "/codefile" + str(subid) + ext).read()

    context = {
        'que1': p,
        'time': endtime,
        'userid': request.user.id - 1,
        'questionid': globid,
        'ext': extension[int(globid) - 1],
        'readcontent': f
    }

    if start > t:
        return render(request, 'about.html', context)
    else:
        if endtime > t:
            return render(request, 'question2.html', context)
        else:
            return render(request, 'test.html')




def queSort(request,id):

        global globid
        globid=str(id)

        print(id)
        t = time_validate(request)
        p = Questions.objects.filter(id=id)
        context={
            'que1':p,
            'time': endtime,
            'userid': request.user.id-1,
            'questionid': globid,
            'ext':extension[int(globid)-1],
            'readcontent':"//Code goes here"

        }


        print(t)
        if start>t:
            return render(request, 'about.html', context)
        else:
            if endtime > t:
                return render(request,'question2.html',context)
            else:
                return render(request,'test.html')


def displayTime(request):
    #print(datetime.now())
    return render(request,"time.html")

def dispatch(request):
    if request.POST['save']==1:
        return save_code_file(request)
    else:
        return compiler(request)

def save_code_file(request):
    t = time_validate(request)
    if t > start:
        if t <= endtime:
            question_folder_create(request)
            code = request.POST["content"]
            s1 = request.POST["content1"]
            print(code)
            print(s1)
            print("g++ " + s1)
            print("./a.out")
            code_file_create(request, code)
            p = Questions.objects.filter(id=id)
            context = {
                'que1': p,
                'time': endtime,
                'msg':"saved",
                'questionid':globid
            }
            return render(request, 'question2.html', context)

        else:
            return render(request, "test.html")
    else:
        return render(request, "about.html")


def compiler(request):
    t=time_validate(request)
    if t>start:
        if t<=endtime:
            question_folder_create(request)
            code = request.POST["content"]
            s1 = request.POST["content1"]
            print(code)
            print(s1)
            print("g++ "+s1)
            print("./a.out")

            t = [0, 0, 0, 0, 0, 0]
            print("Userid")
            print(request.user.id)

            p = Player.objects.all().filter(id=request.user.id-1)
            score=0
            for i in range(5):
                score+=testcase[i]

            n = (100 - score) / 20
            penaltytime = n * addpenalty
            testcaseScore=score

            print(request.user.id)

            question = Questions.objects.get(id=globid)
            curr_time = time_validate(request)
            user=User.objects.get(id=request.user.id)
            ext = request.POST["lang"]
            BestScoreTime=[0,0,0,0,0,0]

            for i in range(6):
                question = Questions.objects.get(id=str(i+1))
                q = Que_attempts.objects.filter(user=user,que=question)

                for x in q:
                    if x.score>t[i]:
                        t[i]=x.score
                        BestScoreTime[i] = x.time


            question = Questions.objects.get(id=globid)
            questionattempt = Que_attempts.objects.create(score=testcaseScore, time=(curr_time), user=user,que=question, penalty=penaltytime,extension=ext)

            z = Player.objects.get(id=request.user.id - 1)
            if testcaseScore > t[int(globid)]:
                z.total_time=z.total_time+time_validate(request)-start-BestScoreTime[int(globid)]

            x=z.total_time+(penaltytime*60)
            z.total_time=x


            q = Player.objects.filter(id=request.user.id - 1).update(total_time=z.total_time)

            questionattempt.save()
            code_file_create(request, code)

            for i in range(6):
                question = Questions.objects.get(id=str(i+1))
                q = Que_attempts.objects.filter(user=user,que=question)

                for x in q:
                    if x.score>t[i]:
                        t[i]=x.score





            q = Player.objects.filter(id=request.user.id - 1).update(total_score=t[0]+t[1]+t[2]+t[3]+t[4]+t[5])

            context1 = {
                'time': time_validate(request),
                'pl': p,
                'list':testcase,
                'score':testcaseScore
            }

            return render(request,"submission.html",context1)

        else:
            return render(request, "test.html")
    else:
        return render(request, "about.html")


def question_folder_create(request):
    #directory="1"

    global globid
    print(globid)
    current_user_id=(request.user.id)-1
    current_user_id=str(current_user_id)
    print(current_user_id)
    #if not os.path.exists(directory):
     #   os.makedirs(directory)
    path = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + current_user_id + "/" + globid
    if not os.path.exists(path):
        #os.chdir(current_user_id)
        print(os.getcwd())
        os.mkdir(path)
    else:
        print("File exists")
    #path = "/PycharmProjects/credenz/1"
    #os.mkdir(path, 0o755)
    #print("File created")
    #import os.path
    #BASE = os.path.dirname(os.path.abspath(__file__))

    #data.txt = open(os.path.join(BASE, "new.txt"))


def user_folder_create(request):
    path1 = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/'

    if not os.path.exists(path1):
        os.mkdir(path1)

    else:
        print("File exists")



    current_user_id=(request.user.id)-1
    print(current_user_id)
    current_user_id=str(current_user_id)
    path = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + current_user_id


    if not os.path.exists(path):
        os.mkdir(path)
        #os.chdir("..")
        #print(os.getcwd())
        #os.mkdir(current_user_id)
    else:
        print("File exists")


def mysubmission(request):
    p1 = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id),que=Questions.objects.filter(id=1))
    p2 = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id), que=Questions.objects.filter(id=2))
    p3 = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id), que=Questions.objects.filter(id=3))
    p4 = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id), que=Questions.objects.filter(id=4))
    p5 = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id), que=Questions.objects.filter(id=5))
    p6 = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id), que=Questions.objects.filter(id=6))

    attemptlist=[p1,p2,p3,p4,p5,p6]
    cnt = Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id)).count()

    countindividualque=[p1.count(),p2.count(),p3.count(),p4.count(),p5.count(),p6.count()]
    #subobj = Que_attempts.objects.all(user=User.objects.filter(id=request.user.id))


    context={
        'attempt1':p1,
        'attempt2':p2,
        'attempt3': p3,
        'attempt4': p4,
        'attempt5': p5,
        'attempt6': p6,

        'cnt':cnt,
        'ciq1':p1.count(),
        'ciq2': p2.count(),
        'ciq3': p3.count(),
        'ciq4': p4.count(),
        'ciq5': p5.count(),
        'ciq6': p6.count()
    }

    return render(request,"Mysubmissions.html",context)



def code_file_create(request,code):

    current_user_id = (request.user.id)-1
    print(request.user.id)
    current_user_id = str(current_user_id)

    #path='/home/neeraj123/PycharmProjects/'+current_user_id+'/'+globid+'/'+'input'+'.txt'
    ext=request.POST["lang"]
    global extension
    extension[int(globid)-1]=ext
    print(ext)


    #os.chdir(globid)
    print(os.getcwd())
    #path=str(path)

    filename=Que_attempts.objects.filter(user=User.objects.filter(id=request.user.id),que=Questions.objects.all().filter(id=globid)).count()
    path = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + current_user_id + "/" + globid
    f=open(path+"/codefile"+str(filename)+ext,'w+')
    f.write(code)
    f.close()



"""def varReceive(request):
    if request.method == 'POST':
        if 'pieFact' in request.POST:
            pieFact = request.POST['pieFact']
            print(pieFact)
            # doSomething with pieFact here...
            return HttpResponse('success')  # if everything is OK
            # nothing went well
    return HttpResponse('FAIL!!!!!')
"""







#@register.assignment_tag()
def assign_tag(self,a):
    b=a
    return b

def ajax1(request):
    return render(request,"ajaxtest.html")

def ajax2(request):
    return render(request,"ajaxtest1.html")

