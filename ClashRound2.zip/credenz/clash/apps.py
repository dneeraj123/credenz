from django.apps import AppConfig


class ClashConfig(AppConfig):
    name = 'clash'

