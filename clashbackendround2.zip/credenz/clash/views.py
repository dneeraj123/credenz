from django.shortcuts import render
from django.contrib.auth import logout
# Create your views here.
from django.contrib.auth import authenticate
from django.contrib.auth import login
from django.contrib.auth.models import User
from .models import Player
from .models import Questions
from random import randint
from django.http import HttpResponse
import os,errno,sys
from django.conf import settings
#from datetime import datetime
import datetime
from django import template
register = template.Library()

start=0*3600
endtime=24*3600+(12*60)
globid=0
lt=100
st=[0,0,0,0,0,0,]
extension=['1','2','3','4','5','6']
"""def my_view(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        #request.session.set_expiry(60)
        return render(request,'instruction.html')
    else:
        #print("Invalid")
        return render(request, 'test.html')
"""
def aboutus(request):
    return render(request, 'about.html')


def time_validate(request):
    h = int(datetime.datetime.now().strftime("%H"))
    m = int(datetime.datetime.now().strftime("%M"))
    s = int(datetime.datetime.now().strftime("%S"))
    t = (h * 3600) + (m * 60) + s

    return t


def time_check(request):
    t=time_validate(request)
    if t<start:
        return render(request, 'about.html')

    else:
        if endtime <= t:
            return render(request, 'test.html')
        else:
            return render(request, 'login.html')


def register(request):
    t=time_validate(request)
    if t<start:
        return render(request, 'about.html')

    else:
        if endtime <= t:
            return render(request, 'test.html')
        else:
            return render(request, 'register.html')



def queList(request):
    #t=time_validate(request)
    h = int(datetime.datetime.now().strftime("%H"))
    m = int(datetime.datetime.now().strftime("%M"))
    s = int(datetime.datetime.now().strftime("%S"))
    t = (h * 3600) + (m * 60) + s
    print(t)
    print(start)
    print(endtime)
    if t < start:
        return render(request, 'about.html')

    else:
        if endtime <= t:
            return render(request, 'test.html')


        else:
            if request.user.is_authenticated():
                p = Questions.objects.all()
                context = {
                    'que': p,
                    'time': endtime,
                }

                user_folder_create(request)
                return render(request, 'questions.html', context)
            else:
                username = request.POST['username']
                password = request.POST['password']
                user = User.objects.create_user(username,"abc@gmail.com",password)
                player = Player.objects.create(p1_name = request.POST['player1_name'],p2_name = request.POST['player2_name'],p1_email = request.POST['player1_email'], p2_email = request.POST['player2_email'],user=user, p1_phone = request.POST['player1_phone'], p2_phone = request.POST['player2_phone'])
    #user.save()

                player.save()
                user = authenticate(request, username=username, password=password)

                if user is not None:
                    h = int(datetime.datetime.now().strftime("%H"))
                    m = int(datetime.datetime.now().strftime("%M"))
                    s = int(datetime.datetime.now().strftime("%S"))
                    global lt
                    lt = (h * 3600) + (m * 60) + s

                    login(request,user)
            #print(lt)
                else:
                    return render(request, 'test.html')

                if request.user.is_authenticated():
                    p = Questions.objects.all()
                    context = {
                        'que': p,
                        'time': endtime,


                    }

                    user_folder_create(request)
                    return render(request, 'questions.html', context)
                else:
                    return render(request, 'test.html')

            #return render(request,'thank.html')


def logout_view(request):
    logout(request)
    return render(request, 'logout.html')


def leaderboard(request):
    t=time_validate(request)
    if t < start:
        return render(request, 'about.html')

    else:

        p=Player.objects.all().order_by('user')

        context={
        'pl':p,
        }

    return render(request, 'leaderboard.html',context)


def que(request):
    #p=Questions.objects.filter(id=1)
    t=time_validate(request)


    if endtime>t and start<=t:
        if request.user.is_authenticated:
            p = Questions.objects.all()
            context = {
                'que': p,
                'endtime': endtime,
            }
            return render(request, 'questions.html', context)
        else:
            user = authenticate(request, username=request.POST["username"], password=request.POST["password"])
            if user is not None:
                h = int(datetime.datetime.now().strftime("%H"))
                m = int(datetime.datetime.now().strftime("%M"))
                s = int(datetime.datetime.now().strftime("%S"))
                global lt
                lt = (h * 3600) + (m * 60) + s

                login(request,user)
                p = Questions.objects.all()
                context={
                    'que':p,
                    'endtime': endtime,
                }
                return render(request,'questions.html',context)
            else:
                return render(request, 'test.html')
    else:
        return render(request, 'about.html')




def queSort(request,id):
    global globid
    globid=str(id)
    print(globid)

    t = time_validate(request)
    p = Questions.objects.filter(id=id)
    context={
        'que1':p,
        'time': endtime,
        'userid': request.user.id-1,
        'questionid': globid,
        'ext':extension[int(globid)-1]
    }

    print(t)
    if start>t:
        return render(request, 'about.html', context)
    else:
        if endtime > t:
           return render(request,'question2.html',context)
        else:
            return render(request,'test.html')


def displayTime(request):
    #print(datetime.now())
    return render(request,"time.html")



def save_code_file(request):
    t = time_validate(request)
    if t > start:
        if t <= endtime:
            question_folder_create(request)
            code = request.POST["content"]
            s1 = request.POST["content1"]
            print(code)
            print(s1)
            print("g++ " + s1)
            print("./a.out")
            code_file_create(request, code)
            p = Questions.objects.filter(id=id)
            context = {
                'que1': p,
                'time': endtime,
                'msg':"saved",
                'questionid':globid
            }
            return render(request, 'question2.html', context)

        else:
            return render(request, "test.html")
    else:
        return render(request, "about.html")

def compiler(request):
    t=time_validate(request)
    if t>start:
        if t<=endtime:
            question_folder_create(request)
            code = request.POST["content"]
            s1 = request.POST["content1"]
            print(code)
            print(s1)
            print("g++ "+s1)
            print("./a.out")
            code_file_create(request,code)

            context1 = {
                'time': time_validate(request)
            }


            q = Player.objects.filter(id=request.user.id - 1).update(total_score=randint(1,100))

            q = Player.objects.filter(id=request.user.id - 1).update(total_time=time_validate(request)-lt)


            return render(request,"submission.html",context1)

        else:
            return render(request, "test.html")
    else:
        return render(request, "about.html")


def question_folder_create(request):
    #directory="1"



    global globid
    print(globid)
    current_user_id=(request.user.id)-1
    current_user_id=str(current_user_id)
    print(current_user_id)
    #if not os.path.exists(directory):
     #   os.makedirs(directory)
    path = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + current_user_id + "/" + globid
    if not os.path.exists(path):
        #os.chdir(current_user_id)
        print(os.getcwd())
        os.mkdir(path)
    else:
        print("File exists")
    #path = "/PycharmProjects/credenz/1"
    #os.mkdir(path, 0o755)
    #print("File created")
    #import os.path
    #BASE = os.path.dirname(os.path.abspath(__file__))

    #data.txt = open(os.path.join(BASE, "new.txt"))


def user_folder_create(request):
    path1 = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/'

    if not os.path.exists(path1):
        os.mkdir(path1)

    else:
        print("File exists")



    current_user_id=(request.user.id)-1
    print(current_user_id)
    current_user_id=str(current_user_id)
    path = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + current_user_id


    if not os.path.exists(path):
        os.mkdir(path)
        #os.chdir("..")
        #print(os.getcwd())
        #os.mkdir(current_user_id)
    else:
        print("File exists")





def code_file_create(request,code):

    current_user_id = (request.user.id)-1
    print(request.user.id)
    current_user_id = str(current_user_id)

    #path='/home/neeraj123/PycharmProjects/'+current_user_id+'/'+globid+'/'+'input'+'.txt'
    ext=request.POST["lang"]
    global extension
    extension[int(globid)-1]=ext
    print(ext)


    #os.chdir(globid)
    print(os.getcwd())
    #path=str(path)
    path = '/home/neeraj123/PycharmProjects/credenz/clash/static/Users/' + current_user_id + "/" + globid
    f=open(path+"/codefile"+ext,'w+')
    f.write(code)
    f.close()



"""def varReceive(request):
    if request.method == 'POST':
        if 'pieFact' in request.POST:
            pieFact = request.POST['pieFact']
            print(pieFact)
            # doSomething with pieFact here...
            return HttpResponse('success')  # if everything is OK
            # nothing went well
    return HttpResponse('FAIL!!!!!')
"""
#@register.assignment_tag()
def assign_tag(self,a):
    b=a
    return b

def ajax1(request):
    return render(request,"ajaxtest.html")

def ajax2(request):
    return render(request,"ajaxtest1.html")